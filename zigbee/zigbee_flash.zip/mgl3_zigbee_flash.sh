#!/bin/sh

DEV=/dev/ttyS2

send() {
  echo -en "$1" > $DEV
}

reset() {
  send '\x1A\xC0\x38\xBC\x7E'
}

send_v4() {
  send '\x00\x42\x21\xa8\x50\xed\x2c\x7e'
}

send_v7() {
  send '\x7d\x31\x43\x21\x57\x54\x2a\x12\x05\x87\x7e'
}

send_v8() {
  send '\x7d\x31\x43\x21\xa9\x54\x2a\x1d\xc9\x7f\x7e'
}

send_v13() {
  send '\x7d\x31\x42\x21\xa9\x54\x2a\x7d\x38\xdc\x7a\x7e'
}

to_btl_7() {
  echo "Rebooting to bootloader"
  send '\x22\x40\x21\x57\x54\xa5\x14\x21\x08\x7e'
}

to_btl_8() {
  echo "Rebooting to bootloader"
  send '\x22\x40\x21\xa9\xdb\x2a\x14\x00\xd2\x7e'
}

to_btl_13() {
  echo "Rebooting to bootloader"
  send '\x22\x43\x21\xa9\x7d\x33\x2a\x16\xb2\x59\x94\xe7\x9e\x7e'
}

ack1() {
  send '\x81\x60\x59\x7E'
}

ack2() {
  send '\x82\x50\x3A\x7E'
}

upload_gbl() {
  echo "Sending upload command"
  send '1'
}

restart() {
  echo "Sending restart command"
  send '2'
}

read_file() {
  CNT=${1:-0}
  FILE=${2:-$DEV}
  NUM_PARAM="-w1"
  if [ "x$CNT" != "x0" ]; then
    NUM_PARAM="-N $CNT -w$CNT"
  fi
  $BUSYBOX od -A n -t x1 $NUM_PARAM $FILE
}

skip_response() {
  read_file $1 > /dev/null
}

read_all() {
  $BUSYBOX od -A n -t x1 $DEV
}

get_version() {
  reset
  skip_response 7
  send_v4
  response=$(read_file 11)
  ack1
  ver_byte=$(echo $response | cut -d' ' -f5)
  if [ "x$ver_byte" = "x5c" ]; then
    echo 8
  elif [ "x$ver_byte" = "x5d" ]; then
    echo 13
  else
    echo 7
  fi
}

# Tools are downloaded from SourceForge (mgl03 project) over plain HTTP:
# busybox wget is available in stock firmware, so curl/openssl are not needed.
# Override to serve the files yourself, e.g. from a PC on the LAN:
#   cd <dir with busybox,sx,libnsl.so.0> && python3 -m http.server
#   TOOLS_URL=http://192.168.1.10:8000 sh mgl3_zigbee_flash.sh
TOOLS_URL="${TOOLS_URL:-http://master.dl.sourceforge.net/project/mgl03/bin}"

# SourceForge bounces every download through downloads.sourceforge.net, which
# has an IPv6 address. Stock busybox wget takes the first address the resolver
# returns (IPv6 first on uClibc) and never tries the next one, so on an
# IPv4-only network it dies with "Network is unreachable". There is no -4
# flag, /etc is read-only squashfs and this busybox cannot bind-mount, so pin
# the host to its IPv4 address in a tmpfs copy of /etc while downloading.
SF_HOST="downloads.sourceforge.net"
ETC_COPY="/tmp/etc.ipv4"

ipv4_of() {
  # stock busybox has no nslookup, parse "PING host (1.2.3.4): ..." in sh
  l=$(ping -4 -c1 -W2 "$1" 2>/dev/null | head -n1)
  l=${l#*(}
  l=${l%%)*}
  case "$l" in
    *.*.*.*) echo "$l" ;;
  esac
}

etc_override_on() {
  [ -d "$ETC_COPY" ] && return 0
  ip=$(ipv4_of "$SF_HOST")
  [ -z "$ip" ] && return 1
  mkdir -p "$ETC_COPY" && cp -a /etc/. "$ETC_COPY/" || return 1
  if ! mount -t tmpfs tmpfs /etc; then
    rm -rf "$ETC_COPY"
    return 1
  fi
  cp -a "$ETC_COPY/." /etc/
  echo "$ip $SF_HOST" >> /etc/hosts
  echo "(pinned $SF_HOST to $ip)"
}

etc_override_off() {
  [ -d "$ETC_COPY" ] || return 0
  umount /etc 2>/dev/null
  rm -rf "$ETC_COPY"
}
# never leave the tmpfs on /etc behind, whatever happens below
trap etc_override_off EXIT

is_elf() {
  head -c 4 "$1" 2>/dev/null | grep -q "ELF"
}

download_tools() {
  echo -n "Downloading $1..."
  url="$TOOLS_URL/$1?viasf=1"
  if ! wget -O "/data/$1" "$url" 2>/dev/null; then
    # most likely the IPv6 problem above - retry with the host pinned to IPv4
    if ! etc_override_on || ! wget -O "/data/$1" "$url" 2>/dev/null; then
      rm -f "/data/$1"
      echo "failed!"
      echo "! Cannot download $1 from $TOOLS_URL"
      echo "! Check network connection and free space in /data"
      exit 1
    fi
  fi
  # make sure we got a real binary, not an HTML page (redirect/parked domain)
  if ! is_elf "/data/$1"; then
    rm -f "/data/$1"
    echo "failed!"
    echo "! Downloaded $1 is not a valid binary (got HTML page?)"
    echo "! Check network connection"
    exit 1
  fi
  chmod +x "/data/$1"
  echo "done!"
}

# some preparations

BUSYBOX="/data/busybox"
# also re-download if the file is damaged by an older version of this script
# (it used to save an HTML page instead of the binary)
if [ ! -f "$BUSYBOX" ] || ! is_elf "$BUSYBOX"; then
  rm -f "$BUSYBOX"
  download_tools busybox
fi

if [ ! -x "$BUSYBOX" ]; then
  chmod +x "$BUSYBOX"
fi

SX=$(which sx)
if [ "x$SX" = "x" ]; then
  SX=/data/sx
fi

if [ ! -f "$SX" ]; then
  download_tools sx
  download_tools libnsl.so.0
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/data
fi

if [ ! -x "$SX" ]; then
  chmod +x "$SX"
fi

# downloads are done - give /etc back before touching the radio
etc_override_off


echo ""
echo "Xiaomi Gateway 3 (mgl3) Zigbee firmware flashing script"
echo ""
echo "Found firmware files:"
pos=1
for f in $(ls *.gbl); do
  HEADER=$(read_file 4 $f)
  if [ "x$HEADER" = "x eb 17 a6 03" ]; then
    echo "$pos: $f"
    eval "firmware$pos=$f"
    pos=$((pos+1))
  fi
done
FIRMWARE_FILE=""
while [ -z $FIRMWARE_FILE ]; do
  read -p "Select firmware: " choice
  FIRMWARE_FILE=$(eval "echo \$firmware$choice")
done
echo "You selected: $FIRMWARE_FILE"
echo ""

echo "Preparing"
echo "Killing default zigbee software"

killall socat
killall ser2net
killall app_monitor.sh
killall daemon_app.sh
killall Lumi_Z3GatewayHost_MQTT

echo "Done"

echo ""
echo "Press Ctrl+C to cancel in 5 seconds!"
sleep 5

echo ""

VERSION=$(get_version)
echo "Detected EZSP v$VERSION"

if [ "v$VERSION" = "v7" ]; then
  send_v7
  ack2
  to_btl_7
elif [ "v$VERSION" = "v13" ]; then
  send_v13
  ack2
  to_btl_13
else
  send_v8
  ack2
  to_btl_8
fi

upload_gbl
$SX -vv -X -b "$FIRMWARE_FILE" < $DEV > $DEV

sleep 1
restart

sleep 3
VERSION=$(get_version)
echo "Detected EZSP v$VERSION"

echo ""
echo "Flashing completed!"
echo ""
echo "Reload XiaomiGateway3 integration or restart Home Assistant"
# br0 exists on older firmwares, newer ones may use wlan0/eth0
IP_ADDR=""
DEF_IFACE=$(ip route 2>/dev/null | grep "^default" | head -n1 | sed "s/.*dev //" | cut -d" " -f1)
for IFACE in $DEF_IFACE br0 wlan0 eth0; do
  [ -z "$IFACE" ] && continue
  IP_ADDR=$(ifconfig "$IFACE" 2>/dev/null | grep "inet addr" | cut -d":" -f2 | cut -d" " -f1)
  [ -n "$IP_ADDR" ] && break
done
echo "Configure zigbee2mqtt port address to: tcp://$IP_ADDR:8888"
